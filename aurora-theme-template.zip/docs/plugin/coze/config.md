# 插件配置

- appId

  > 必需,leanCloud中的appId

- appKey

  > 必需，leanCloud中的appKey

​      

- masterKey

  > 必需，leanCloud中的masterKey

- avatarPath

  > `可选`说说头像url

- registerPath

  > `可选`自定义插件默认提供的注册页面路由，请在前面加上`/`

- onlyAdministrator

  > `可选`是否运行其他注册的用户发布说说，true表示只有管理员可以发布



## 组件使用

[组件使用](./component.md)