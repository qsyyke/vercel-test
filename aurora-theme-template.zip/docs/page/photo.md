---
tag: [相册,photo]
---



# 相册功能

![image-20210911121146092](https://ooszy.cco.vin/img/blog-note/image-20210911121146092.png?x-oss-process=style/pictureProcess1)



## 配置

> 此页面手机端默认是两列，PC端为5列，主题会自动计算宽度

主题会寻找在`docs/photos/readme.md`中的所有图片，在此页面中展示，所以一定要在`docs/photos/readme.md`中，加入自己的图片，可以是本地，或者图片url连接，如果不存在此文件，那么会使用默认的图片进行展示

```md
//docs/photos/reasdme.md
![image-20210910160320304](https://ooszy.cco.vin/img/blog-note/image-20210910160320304.png?x-oss-process=style/pictureProcess1)

![image-20210910160335602](https://ooszy.cco.vin/img/blog-note/image-20210910160335602.png?x-oss-process=style/pictureProcess1)

![image-20210910160455739](https://ooszy.cco.vin/img/blog-note/image-20210910160455739.png?x-oss-process=style/pictureProcess1)

![image-20210910160510785](https://ooszy.cco.vin/img/blog-note/image-20210910160510785.png?x-oss-process=style/pictureProcess1)

![image-20210910160523968](https://ooszy.cco.vin/img/blog-note/image-20210910160523968.png?x-oss-process=style/pictureProcess1)

![image-20210910160541591](https://ooszy.cco.vin/img/blog-note/image-20210910160541591.png?x-oss-process=style/pictureProcess1)

![image-20210910160601558](https://ooszy.cco.vin/img/blog-note/image-20210910160601558.png?x-oss-process=style/pictureProcess1)

![image-20210910160650553](https://ooszy.cco.vin/img/blog-note/image-20210910160650553.png?x-oss-process=style/pictureProcess1)

![image-20210910160702449](https://ooszy.cco.vin/img/blog-note/image-20210910160702449.png?x-oss-process=style/pictureProcess1)

![image-20210910160713886](https://ooszy.cco.vin/img/blog-note/image-20210910160713886.png?x-oss-process=style/pictureProcess1)

![image-20210910160725684](https://ooszy.cco.vin/img/blog-note/image-20210910160725684.png?x-oss-process=style/pictureProcess1)
```





## 标签页面配置

[标签页面配置](tag.md)