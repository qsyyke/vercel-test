import { PlayerPluginOptions } from './vuepress-plugin-player';
export * from './vuepress-plugin-player';
export default PlayerPluginOptions;
